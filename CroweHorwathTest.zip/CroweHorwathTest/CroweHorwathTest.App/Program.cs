﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CroweHorwathTest.App.Models;

namespace CroweHorwathTest.App
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("{0}", Start.Go());

            //The Web Service works...just uncomment the lines below
            //and run the service
            //there is a local database with one record

            //Console.WriteLine("My name is...");
            //CrowHorwathTestApi api = new CrowHorwathTestApi(Properties.Settings.Default.CroweHorwathTestApiUrl);
            //api.GetUser().Wait();           

        }
    }
}
