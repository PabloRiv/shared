﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;



namespace CroweHorwathTest.App.Models
{
    public class CrowHorwathTestApi: ServiceBase  
    {
        private HttpClient service = new HttpClient();
        public CrowHorwathTestApi(string path)
        {
            this.Path = path;
            service.BaseAddress = new Uri(this.Path);
            service.DefaultRequestHeaders.Accept.Clear();
            service.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task GetUser()
        {
            using (service)
            {
                HttpResponseMessage response = await service.GetAsync("api/Users");
                response.EnsureSuccessStatusCode();
                if(response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<List<User>>(json);
                    foreach(User user in data)
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("{0}", user.Name);
                        Console.WriteLine("\n");
                    }

                }
            }
        }
    }
}
