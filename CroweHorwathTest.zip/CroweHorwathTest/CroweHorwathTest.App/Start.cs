﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CroweHorwathTest.App
{
    public static class Start
    {
        public static string Go()
        {
            string message = "Hello World";
            return message;
        }
    }
}
