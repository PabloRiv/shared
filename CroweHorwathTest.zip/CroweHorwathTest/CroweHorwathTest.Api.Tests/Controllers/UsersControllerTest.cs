﻿using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CroweHorwathTest.Api;
using CroweHorwathTest.Api.Controllers;

namespace CroweHorwathTest.Api.Tests.Controllers
{
    [TestClass]
    public class UsersControllerTest
    {
        [TestMethod]
        public void GetUsers()
        {
            // Arrange
            UsersController controller = new UsersController();

            // Act
            ViewResult result = controller.GetUsers() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Perry Biava", result.ViewBag.User.Name);
        }
    }
}
