namespace CroweHorwathTest.Api
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class CandidateModel : DbContext
    {
        public CandidateModel()
            : base("name=CandidateModel")
        {
        }

        public virtual DbSet<Skill> Skills { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Skill>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Skill>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .HasMany(e => e.Skills)
                .WithRequired(e => e.User)
                .WillCascadeOnDelete(false);
        }
    }
}
